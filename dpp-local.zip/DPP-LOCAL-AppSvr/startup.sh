cd /home/DPP-LOCAL/DPP-LOCAL-AppSvr
./StartDPPLOCALAppSvr &
exit 0
