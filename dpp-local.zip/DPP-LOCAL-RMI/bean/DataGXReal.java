package bean;

public class DataGXReal {

	private String gx_id;	
	private String diameter;
	private String length;
	private String material;
	private String value;
	public String getGx_id() {
		return gx_id;
	}
	public void setGx_id(String gx_id) {
		this.gx_id = gx_id;
	}
	public String getDiameter() {
		return diameter;
	}
	public void setDiameter(String diameter) {
		this.diameter = diameter;
	}
	public String getLength() {
		return length;
	}
	public void setLength(String length) {
		this.length = length;
	}
	public String getMaterial() {
		return material;
	}
	public void setMaterial(String material) {
		this.material = material;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	
	
	
	
	
}
