package bean;

public class DataGJReal {

	private String gj_id;	
	private String top_height;
	private String base_height;
	private String material;
	private String value;
	public String getGj_id() {
		return gj_id;
	}
	public void setGj_id(String gj_id) {
		this.gj_id = gj_id;
	}
	public String getTop_height() {
		return top_height;
	}
	public void setTop_height(String top_height) {
		this.top_height = top_height;
	}
	public String getBase_height() {
		return base_height;
	}
	public void setBase_height(String base_height) {
		this.base_height = base_height;
	}
	public String getMaterial() {
		return material;
	}
	public void setMaterial(String material) {
		this.material = material;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	
	
}
